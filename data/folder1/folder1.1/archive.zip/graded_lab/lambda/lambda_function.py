import os
import json
import logging
import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

sqs = boto3.client('sqs')  # client is required to interact with sqs


def lambda_handler(event, context):
    logger.info('## ENVIRONMENT VARIABLES')
    logger.info(os.environ)
    logger.info('## EVENT')
    logger.info(event)
    print(os.getenv("url_input"))

    number1 = float(json.loads(event["Records"][0]["body"])["number1"])
    number2 = float(json.loads(event["Records"][0]["body"])["number2"])
    operation = json.loads(event["Records"][0]["body"])["operation"]

    if operation == "+":
        res = number1 + number2
    elif operation == "-":
        res = number1 - number2
    elif operation == "*":
        res = number1 * number2
    elif operation == "/":
        res = number1 / number2

    res = str(res)

    sqs.send_message(
        QueueUrl=os.getenv("url_input"),
        MessageBody=json.dumps({"body": res})
    )

    return {
        'statusCode': 200,
        'body': res
    }
