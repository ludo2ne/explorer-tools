#!/usr/bin/env python
from constructs import Construct
from cdktf import App, TerraformStack, TerraformAsset, AssetType
from cdktf_cdktf_provider_aws.provider import AwsProvider
from cdktf_cdktf_provider_aws.lambda_function import LambdaFunction
from cdktf_cdktf_provider_aws.sqs_queue import SqsQueue
from cdktf_cdktf_provider_aws.lambda_event_source_mapping import LambdaEventSourceMapping
import boto3


class MyStack(TerraformStack):
    def __init__(self, scope: Construct, id: str):
        super().__init__(scope, id)

        AwsProvider(self, "AWS", region="us-east-1")

        # Packagage du code
        code = TerraformAsset(
            self, "code",
            path="./lambda",
            type=AssetType.ARCHIVE
        )

        # Create input queue
        input_queue = SqsQueue(
            self,
            "queue_in",
            name="input_queue_graded",
            visibility_timeout_seconds=60
        )

        # Create output queue
        output_queue = SqsQueue(
            self,
            "queue_out",
            name="output_queue_graded",
            visibility_timeout_seconds=60
        )

        # Create Lambda function
        lambda_function = LambdaFunction(self,
                                         "lambda",
                                         function_name="graded_lambda",
                                         runtime="python3.8",
                                         memory_size=128,
                                         timeout=60,
                                         role="arn:aws:iam::712226769808:role/LabRole",
                                         filename=code.path,
                                         handler="lambda_function.lambda_handler",
                                         environment={
                                             "variables": {"url_input": output_queue.url}}
                                         )

        # Link SQS as Lambda's source
        LambdaEventSourceMapping(
            self, "event_source_mapping",
            event_source_arn=input_queue.arn,
            function_name=lambda_function.arn
        )


app = App()
MyStack(app, "graded_lab")

app.synth()
